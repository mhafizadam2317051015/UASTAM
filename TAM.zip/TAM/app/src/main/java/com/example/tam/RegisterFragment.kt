package com.example.tam

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.tam.data.UserManager

class RegisterFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_register, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etNama = view.findViewById<EditText>(R.id.et_nama)
        val etEmail = view.findViewById<EditText>(R.id.et_email)
        val etPassword = view.findViewById<EditText>(R.id.et_password)
        val etKonfirmasiPassword = view.findViewById<EditText>(R.id.et_konfirmasi_password)
        val btnDaftar = view.findViewById<Button>(R.id.btn_daftar)
        val tvMasuk = view.findViewById<TextView>(R.id.tv_masuk)

        val userManager = UserManager(requireContext())

        btnDaftar?.setOnClickListener {
            val nama = etNama?.text.toString().trim()
            val email = etEmail?.text.toString().trim()
            val password = etPassword?.text.toString().trim()
            val konfirmasiPassword = etKonfirmasiPassword?.text.toString().trim()

            when {
                nama.isEmpty() -> Toast.makeText(requireContext(), "Nama wajib diisi", Toast.LENGTH_SHORT).show()
                email.isEmpty() -> Toast.makeText(requireContext(), "Email wajib diisi", Toast.LENGTH_SHORT).show()
                password.isEmpty() -> Toast.makeText(requireContext(), "Password wajib diisi", Toast.LENGTH_SHORT).show()
                password.length < 6 -> Toast.makeText(requireContext(), "Password minimal 6 karakter", Toast.LENGTH_SHORT).show()
                password != konfirmasiPassword -> Toast.makeText(requireContext(), "Password tidak cocok", Toast.LENGTH_SHORT).show()
                else -> {
                    if (userManager.registerUser(nama, email, password)) {
                        Toast.makeText(requireContext(), "Registrasi berhasil", Toast.LENGTH_SHORT).show()
                        findNavController().navigate(R.id.action_registerFragment_to_loginFragment)
                    } else {
                        Toast.makeText(requireContext(), "Email sudah terdaftar", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        tvMasuk?.setOnClickListener {
            findNavController().navigate(R.id.action_registerFragment_to_loginFragment)
        }
    }
}
