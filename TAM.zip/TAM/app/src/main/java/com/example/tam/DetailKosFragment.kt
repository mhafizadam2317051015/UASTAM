package com.example.tam

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class DetailKosFragment : Fragment(R.layout.fragment_detail_kos) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Back button
        val btnBack = view.findViewById<ImageView>(R.id.btnBack)
        btnBack.setOnClickListener {
            findNavController().popBackStack()
        }

        // Bookmark button
        val btnBookmark = view.findViewById<ImageView>(R.id.btnBookmark)
        btnBookmark.setOnClickListener {
            // Toggle bookmark state
        }

        // Share button
        val btnShare = view.findViewById<ImageView>(R.id.btnShare)
        btnShare.setOnClickListener {
            // Handle share functionality
        }

        // Navigate to PetaKosFragment when clicking Lokasi card
        val cardLokasiKos = view.findViewById<View>(R.id.cardLokasiKos)
        cardLokasiKos.setOnClickListener {
            findNavController().navigate(R.id.action_detailKosFragment_to_petaKosFragment)
        }

        // Navigate to FasilitasKosFragment when clicking Fasilitas card
        val cardFasilitasKos = view.findViewById<View>(R.id.cardFasilitasKos)
        cardFasilitasKos.setOnClickListener {
            findNavController().navigate(R.id.action_detailKosFragment_to_fasilitasKosFragment)
        }

        // Navigate to PeraturanKosFragment when clicking Peraturan card
        val cardPeraturanKos = view.findViewById<View>(R.id.cardPeraturanKos)
        cardPeraturanKos.setOnClickListener {
            findNavController().navigate(R.id.action_detailKosFragment_to_peraturanKosFragment)
        }
    }
}
