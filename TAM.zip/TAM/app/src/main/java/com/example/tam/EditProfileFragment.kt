package com.example.tam

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.tam.data.User
import com.example.tam.data.UserManager

class EditProfileFragment : Fragment() {

    private lateinit var userManager: UserManager
    private var currentUser: User? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_edit_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userManager = UserManager(requireContext())
        currentUser = userManager.getCurrentUser()

        val btnBack = view.findViewById<ImageView>(R.id.btnBack)
        val etNama = view.findViewById<EditText>(R.id.etNama)
        val etEmail = view.findViewById<EditText>(R.id.etEmail)
        val etPhone = view.findViewById<EditText>(R.id.etPhone)
        val spinnerGender = view.findViewById<Spinner>(R.id.spinnerGender)

        // Icon pensil untuk edit foto profil
        val btnEditPhoto = view.findViewById<ImageView>(R.id.imgProfile)

        // Setup spinner for gender
        val genderOptions = arrayOf("Pilih Jenis Kelamin", "Laki-laki", "Perempuan")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, genderOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerGender.adapter = adapter

        // Load current user data
        currentUser?.let { user ->
            etNama.setText(user.nama)
            etEmail.setText(user.email)
            etPhone.setText(user.nomorTelepon)

            val genderIndex = when (user.jenisKelamin) {
                "Laki-laki" -> 1
                "Perempuan" -> 2
                else -> 0
            }
            spinnerGender.setSelection(genderIndex)
        }

        btnBack.setOnClickListener {
            findNavController().popBackStack()
        }

        // Click listener untuk icon pensil edit foto
        btnEditPhoto?.setOnClickListener {
            val dialog = EditProfile2Fragment()
            dialog.show(parentFragmentManager, "EditProfile2Fragment")
        }

        // Add save button functionality
        val btnSave = view.findViewById<Button>(R.id.btnSave)


        btnSave.setOnClickListener {
            val nama = etNama.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val gender = if (spinnerGender.selectedItemPosition > 0) {
                genderOptions[spinnerGender.selectedItemPosition]
            } else ""

            if (nama.isEmpty()) {
                Toast.makeText(requireContext(), "Nama wajib diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (email.isEmpty()) {
                Toast.makeText(requireContext(), "Email wajib diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            currentUser?.let { user ->
                val updatedUser = user.copy(
                    nama = nama,
                    email = email,
                    nomorTelepon = phone,
                    jenisKelamin = gender
                )

                if (userManager.updateUserProfile(updatedUser)) {
                    Toast.makeText(requireContext(), "Profile berhasil diupdate", Toast.LENGTH_SHORT).show()
                    findNavController().popBackStack()
                } else {
                    Toast.makeText(requireContext(), "Gagal mengupdate profile", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}