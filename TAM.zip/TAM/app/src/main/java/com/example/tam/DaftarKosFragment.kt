package com.example.tam

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class DaftarKosFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_daftar_kos, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Add functionality for listing all kos
        // This could include a RecyclerView with kos items

        val etSearch1 = view.findViewById<EditText>(R.id.etSearch)
        etSearch1.setOnClickListener {
            findNavController().navigate(R.id.action_daftarKosFragment_to_hasilPencarianFragment)
        }

        val card1 = view.findViewById<View>(R.id.imgKos1).parent as View
        card1.setOnClickListener {
            findNavController().navigate(R.id.action_daftarKosFragment_to_detailKosFragment)
        }

        val card2 = view.findViewById<View>(R.id.imgKos2).parent as View
        card2.setOnClickListener {
            findNavController().navigate(R.id.action_daftarKosFragment_to_detailKosFragment)
        }

        val card3 = view.findViewById<View>(R.id.imgKos3).parent as View
        card3.setOnClickListener {
            findNavController().navigate(R.id.action_daftarKosFragment_to_detailKosFragment)
        }

        val card4 = view.findViewById<View>(R.id.imgKos4).parent as View
        card4.setOnClickListener {
            findNavController().navigate(R.id.action_daftarKosFragment_to_detailKosFragment)
        }
    }
}
