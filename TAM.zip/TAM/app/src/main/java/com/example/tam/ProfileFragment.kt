package com.example.tam

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.tam.data.UserManager

class ProfileFragment : Fragment() {

    private lateinit var userManager: UserManager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userManager = UserManager(requireContext())

        // Update profile information
        updateProfileInfo(view)

        // Setup click listeners for menu items
        setupMenuClickListeners(view)
    }

    override fun onResume() {
        super.onResume()
        // Update profile info when returning from edit profile
        view?.let { updateProfileInfo(it) }
    }

    private fun updateProfileInfo(view: View) {
        val currentUser = userManager.getCurrentUser()

        // Find TextViews for user info (you'll need to add these IDs to your layout)
        val tvUserName = view.findViewById<TextView>(R.id.tv_user_name)
        val tvUserEmail = view.findViewById<TextView>(R.id.tv_user_email)

        currentUser?.let { user ->
            tvUserName?.text = user.nama
            tvUserEmail?.text = user.email
        }
    }

    private fun setupMenuClickListeners(view: View) {
        // Edit Profile click listener
        view.findViewById<View>(R.id.menu_edit_profile)?.setOnClickListener {
            findNavController().navigate(R.id.action_profileFragment_to_editProfileFragment)
        }
        view.findViewById<View>(R.id.editPoto)?.setOnClickListener {
            findNavController().navigate(R.id.action_profileFragment_to_editProfile2Fragment)
        }

        // Logout click listener
        view.findViewById<View>(R.id.menu_logout)?.setOnClickListener {
            userManager.logoutUser()
            Toast.makeText(requireContext(), "Logout berhasil", Toast.LENGTH_SHORT).show()
            findNavController().navigate(R.id.action_profileFragment_to_loginFragment)
        }
    }
}
