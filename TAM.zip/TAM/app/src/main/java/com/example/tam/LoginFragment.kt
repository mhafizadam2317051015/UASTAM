package com.example.tam

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.tam.data.UserManager

class LoginFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val email = view.findViewById<EditText>(R.id.et_email_login)
        val password = view.findViewById<EditText>(R.id.et_password_login)
        val btnMasuk = view.findViewById<Button>(R.id.btn_masuk)
        val tvDaftar = view.findViewById<TextView>(R.id.tv_daftar)

        val userManager = UserManager(requireContext())

        btnMasuk.setOnClickListener {
            val emailText = email.text.toString().trim()
            val passText = password.text.toString().trim()

            if (emailText.isEmpty() || passText.isEmpty()) {
                Toast.makeText(requireContext(), "Email dan Password wajib diisi", Toast.LENGTH_SHORT).show()
            } else {
                if (userManager.loginUser(emailText, passText)) {
                    Toast.makeText(requireContext(), "Login berhasil", Toast.LENGTH_SHORT).show()
                    findNavController().navigate(R.id.action_loginFragment_to_berandaFragment)
                } else {
                    Toast.makeText(requireContext(), "Email atau Password salah", Toast.LENGTH_SHORT).show()
                }
            }
        }

        tvDaftar.setOnClickListener {
            findNavController().navigate(R.id.action_loginFragment_to_registerFragment)
        }
    }
}
