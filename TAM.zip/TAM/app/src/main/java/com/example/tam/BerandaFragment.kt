package com.example.tam

import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.tam.data.UserManager
import android.widget.TextView

class BerandaFragment : Fragment(R.layout.fragment_beranda) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val userManager = UserManager(requireContext())
        val tvWelcome = view.findViewById<TextView>(R.id.tvWelcome)

        // Update welcome message with user's name
        val currentUser = userManager.getCurrentUser()
        if (currentUser != null) {
            tvWelcome.text = "Selamat Datang\ndi KostFinder, ${currentUser.nama}"
        }

        // Search click - navigate to HasilPencarianFragment
        val etSearch = view.findViewById<EditText>(R.id.etSearch)
        etSearch.setOnClickListener {
            findNavController().navigate(R.id.action_berandaFragment_to_hasilPencarianFragment)
        }

        // Click listeners for recommendation cards to navigate to DetailKosFragment
        val card1 = view.findViewById<View>(R.id.image1).parent as View
        card1.setOnClickListener {
            findNavController().navigate(R.id.action_berandaFragment_to_detailKosFragment)
        }

        val card2 = view.findViewById<View>(R.id.image2).parent as View
        card2.setOnClickListener {
            findNavController().navigate(R.id.action_berandaFragment_to_detailKosFragment)
        }

        val card3 = view.findViewById<View>(R.id.image3).parent as View
        card3.setOnClickListener {
            findNavController().navigate(R.id.action_berandaFragment_to_detailKosFragment)
        }

        val card4 = view.findViewById<View>(R.id.image4).parent as View
        card4.setOnClickListener {
            findNavController().navigate(R.id.action_berandaFragment_to_detailKosFragment)
        }

        // Bookmark click listeners
        view.findViewById<View>(R.id.bookmark1).setOnClickListener {
            // Toggle bookmark state
        }

        view.findViewById<View>(R.id.bookmark2).setOnClickListener {
            // Toggle bookmark state
        }

        view.findViewById<View>(R.id.bookmark3).setOnClickListener {
            // Toggle bookmark state
        }

        view.findViewById<View>(R.id.bookmark4).setOnClickListener {
            // Toggle bookmark state
        }
    }
}
