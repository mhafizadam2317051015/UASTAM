package com.example.tam

import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class HasilPencarianFragment : Fragment(R.layout.fragment_hasil_pencarian) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Click on search result card to navigate to DetailKosFragment
        val imgKos1 = view.findViewById<View>(R.id.imgKos1)
        val cardParent = imgKos1.parent.parent as View
        cardParent.setOnClickListener {
            findNavController().navigate(R.id.action_hasilPencarianFragment_to_detailKosFragment)
        }

        // Bookmark click listener
        view.findViewById<View>(R.id.bookmark1).setOnClickListener {
            // Toggle bookmark state
        }

        // Search bar click
        val etSearch = view.findViewById<EditText>(R.id.etSearch)
        etSearch.setOnClickListener {
            // Handle search functionality
        }
    }
}
