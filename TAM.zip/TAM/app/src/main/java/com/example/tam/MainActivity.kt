package com.example.tam

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.example.tam.data.UserManager

class MainActivity : AppCompatActivity() {

    private lateinit var navController: NavController
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var userManager: UserManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        userManager = UserManager(this)

        // Setup Navigation
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        // Setup Bottom Navigation
        bottomNav = findViewById(R.id.bottom_nav)

        // Check if user is logged in and navigate accordingly
        checkLoginStatus()

        // Setup navigation with bottom nav
        NavigationUI.setupWithNavController(bottomNav, navController)

        // Handle bottom navigation item selection manually if needed
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.berandaFragment -> {
                    navController.navigate(R.id.berandaFragment)
                    true
                }
                R.id.daftarKosFragment -> {
                    navController.navigate(R.id.daftarKosFragment)
                    true
                }
                R.id.bookmarkFragment -> {
                    navController.navigate(R.id.bookmarkFragment)
                    true
                }
                R.id.profileFragment -> {
                    navController.navigate(R.id.profileFragment)
                    true
                }
                else -> false
            }
        }

        // Hide bottom navigation for certain fragments
        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.splashScreenFragment,
                R.id.welcomePageFragment,
                R.id.loginFragment,
                R.id.registerFragment,
                R.id.detailKosFragment,
                R.id.peraturanKosFragment,
                R.id.fasilitasKosFragment,
                R.id.petaKosFragment,
                R.id.editProfileFragment -> {
                    bottomNav.visibility = View.GONE
                }
                else -> {
                    bottomNav.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun checkLoginStatus() {
        // If user is already logged in, navigate to beranda
        if (userManager.isLoggedIn()) {
            navController.navigate(R.id.berandaFragment)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}
