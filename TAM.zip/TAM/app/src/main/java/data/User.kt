package com.example.tam.data

data class User(
    val id: String = "",
    val nama: String = "",
    val email: String = "",
    val password: String = "",
    val jenisKelamin: String = "",
    val nomorTelepon: String = ""
)
