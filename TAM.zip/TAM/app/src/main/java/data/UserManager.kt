package com.example.tam.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class UserManager(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        private const val KEY_USERS = "users"
        private const val KEY_CURRENT_USER = "current_user"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
    }

    // Menyimpan semua user yang terdaftar
    private fun saveUsers(users: List<User>) {
        val json = gson.toJson(users)
        sharedPreferences.edit().putString(KEY_USERS, json).apply()
    }

    // Mengambil semua user yang terdaftar
    private fun getUsers(): MutableList<User> {
        val json = sharedPreferences.getString(KEY_USERS, null)
        return if (json != null) {
            val type = object : TypeToken<MutableList<User>>() {}.type
            gson.fromJson(json, type)
        } else {
            mutableListOf()
        }
    }

    // Registrasi user baru
    fun registerUser(nama: String, email: String, password: String): Boolean {
        val users = getUsers()

        // Cek apakah email sudah terdaftar
        if (users.any { it.email == email }) {
            return false // Email sudah terdaftar
        }

        // Buat user baru
        val newUser = User(
            id = System.currentTimeMillis().toString(),
            nama = nama,
            email = email,
            password = password
        )

        users.add(newUser)
        saveUsers(users)
        return true
    }

    // Login user
    fun loginUser(email: String, password: String): Boolean {
        val users = getUsers()
        val user = users.find { it.email == email && it.password == password }

        return if (user != null) {
            // Simpan user yang sedang login
            val json = gson.toJson(user)
            sharedPreferences.edit()
                .putString(KEY_CURRENT_USER, json)
                .putBoolean(KEY_IS_LOGGED_IN, true)
                .apply()
            true
        } else {
            false
        }
    }

    // Mendapatkan user yang sedang login
    fun getCurrentUser(): User? {
        val json = sharedPreferences.getString(KEY_CURRENT_USER, null)
        return if (json != null) {
            gson.fromJson(json, User::class.java)
        } else {
            null
        }
    }

    // Cek apakah user sudah login
    fun isLoggedIn(): Boolean {
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    // Update profile user
    fun updateUserProfile(updatedUser: User): Boolean {
        val users = getUsers()
        val currentUser = getCurrentUser() ?: return false

        // Cari dan update user di list
        val index = users.indexOfFirst { it.id == currentUser.id }
        if (index != -1) {
            users[index] = updatedUser.copy(id = currentUser.id, password = currentUser.password)
            saveUsers(users)

            // Update current user
            val json = gson.toJson(users[index])
            sharedPreferences.edit().putString(KEY_CURRENT_USER, json).apply()
            return true
        }
        return false
    }

    // Logout user
    fun logoutUser() {
        sharedPreferences.edit()
            .remove(KEY_CURRENT_USER)
            .putBoolean(KEY_IS_LOGGED_IN, false)
            .apply()
    }
}
